package app.astra

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.LocalDate

private val Context.store by preferencesDataStore("astra_prefs")

/** Цвета акцента (лайки, кнопки, серия). Первый — по умолчанию. */
val AccentPalette = listOf(
    0xFFFF3B5C.toInt(), // rose
    0xFF8B5CF6.toInt(), // violet
    0xFF22D3EE.toInt(), // cyan
    0xFF34D399.toInt(), // mint
    0xFFFBBF24.toInt(), // amber
    0xFFF8FAFC.toInt(), // white
)

data class Streak(val days: Int, val lastDay: String)

class Prefs(private val context: Context) {
    private val accentKey = intPreferencesKey("accent")
    private val streakKey = intPreferencesKey("streak_days")
    private val lastDayKey = stringPreferencesKey("streak_last_day")
    private val nameKey = stringPreferencesKey("username")

    val accent: Flow<Int> = context.store.data.map { it[accentKey] ?: AccentPalette[0] }
    val username: Flow<String> = context.store.data.map { it[nameKey] ?: "astra" }
    val streak: Flow<Streak> = context.store.data.map {
        Streak(it[streakKey] ?: 0, it[lastDayKey] ?: "")
    }

    suspend fun setAccent(color: Int) = context.store.edit { it[accentKey] = color }
    suspend fun setUsername(name: String) = context.store.edit { it[nameKey] = name.take(24) }

    /**
     * Серия продлевается, когда пользователь реально смотрит ленту:
     * один раз в день. Пропущенный день сбрасывает серию в 1.
     */
    suspend fun touchStreak() {
        val today = LocalDate.now()
        context.store.edit { p ->
            val last = p[lastDayKey]?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
            val days = p[streakKey] ?: 0
            when {
                last == today -> Unit
                last == today.minusDays(1) -> {
                    p[streakKey] = days + 1
                    p[lastDayKey] = today.toString()
                }
                else -> {
                    p[streakKey] = 1
                    p[lastDayKey] = today.toString()
                }
            }
        }
    }
}
