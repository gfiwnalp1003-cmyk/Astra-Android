package app.astra

import android.net.Uri
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FeedScreen(repo: VideoRepo, onWatched: () -> Unit, onAdd: () -> Unit) {
    val videos by repo.videos.collectAsState()

    if (videos.isEmpty()) {
        Column(
            Modifier.fillMaxSize().padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Text("Здесь пока пусто", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(8.dp))
            Text(
                "Добавь первое видео со своего телефона",
                color = Color(0xFF8A8A8E),
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(24.dp))
            Button(onClick = onAdd, shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)) {
                Text("Добавить видео")
            }
        }
        return
    }

    val pager = rememberPagerState { videos.size }
    LaunchedEffect(pager.currentPage) { onWatched() }

    VerticalPager(
        state = pager,
        modifier = Modifier.fillMaxSize(),
        beyondViewportPageCount = 0,
        key = { videos[it].id },
    ) { page ->
        VideoPage(videos[page], repo, active = pager.currentPage == page)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun VideoPage(video: Video, repo: VideoRepo, active: Boolean) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val accent = LocalAccent.current

    var paused by remember(video.id) { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    // Плеер живёт только у видео на экране: на бюджетных телефонах
    // (Realme C35 и т.п.) число аппаратных декодеров ограничено.
    var player by remember(video.id) { mutableStateOf<ExoPlayer?>(null) }
    DisposableEffect(active) {
        if (active) {
            paused = false
            val p = ExoPlayer.Builder(context).build().apply {
                setMediaItem(MediaItem.fromUri(Uri.fromFile(File(video.path))))
                repeatMode = Player.REPEAT_MODE_ONE
                playWhenReady = true
                prepare()
            }
            player = p
            onDispose {
                p.release()
                player = null
            }
        } else {
            onDispose { }
        }
    }

    // Не играть звук, когда приложение свернуто.
    val owner = LocalContext.current as? LifecycleOwner
    DisposableEffect(owner, player) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE -> player?.pause()
                Lifecycle.Event.ON_RESUME -> if (!paused) player?.play()
                else -> Unit
            }
        }
        owner?.lifecycle?.addObserver(observer)
        onDispose { owner?.lifecycle?.removeObserver(observer) }
    }

    Box(Modifier.fillMaxSize()) {
        AndroidView(
            factory = {
                PlayerView(it).apply {
                    useController = false
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                }
            },
            update = { it.player = player },
            modifier = Modifier
                .fillMaxSize()
                .combinedClickable(
                    onClick = {
                        paused = !paused
                        player?.playWhenReady = !paused
                    },
                    onLongClick = { confirmDelete = true },
                ),
        )

        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(220.dp)
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000))))
        )

        Column(
            Modifier
                .align(Alignment.BottomStart)
                .padding(start = 16.dp, bottom = 28.dp, end = 88.dp)
        ) {
            Text("@${video.author}", color = Color.White)
            if (video.caption.isNotEmpty()) {
                Spacer(Modifier.height(4.dp))
                Text(video.caption, color = Color.White.copy(alpha = 0.85f))
            }
        }

        Icon(
            imageVector = if (video.liked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
            contentDescription = null,
            tint = if (video.liked) accent else Color.White,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 18.dp, bottom = 28.dp)
                .size(32.dp)
                .clickable { scope.launch { repo.toggleLike(video.id) } },
        )
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            title = { Text("Удалить видео?") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    scope.launch { repo.delete(video.id) }
                }) { Text("Удалить") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Отмена") } },
        )
    }
}
