package app.astra

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val prefs = Prefs(applicationContext)
        val repo = VideoRepo(applicationContext)
        setContent {
            val accent by prefs.accent.collectAsState(initial = AccentPalette[0])
            AstraTheme(accent) { MainShell(prefs, repo) }
        }
    }
}

@Composable
private fun MainShell(prefs: Prefs, repo: VideoRepo) {
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    var pending by remember { mutableStateOf<Uri?>(null) }
    var caption by remember { mutableStateOf("") }
    val username by prefs.username.collectAsState(initial = "astra")

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            caption = ""
            pending = uri
        }
    }
    val pickVideo = {
        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
    }

    Scaffold(
        containerColor = Color.Black,
        bottomBar = {
            NavigationBar(containerColor = Color.Black, tonalElevation = 0.dp) {
                NavigationBarItem(
                    selected = tab == 0, onClick = { tab = 0 },
                    icon = { Icon(Icons.Outlined.Home, null) }, label = { Text("Лента") },
                    colors = navColors(),
                )
                NavigationBarItem(
                    selected = false, onClick = { pickVideo() },
                    icon = { Icon(Icons.Filled.Add, null) }, label = { Text("Добавить") },
                    colors = navColors(),
                )
                NavigationBarItem(
                    selected = tab == 1, onClick = { tab = 1 },
                    icon = { Icon(Icons.Outlined.Person, null) }, label = { Text("Профиль") },
                    colors = navColors(),
                )
            }
        },
    ) { padding ->
        Box(Modifier.padding(bottom = padding.calculateBottomPadding())) {
            when (tab) {
                0 -> FeedScreen(
                    repo = repo,
                    onWatched = { scope.launch { prefs.touchStreak() } },
                    onAdd = { pickVideo() },
                )
                else -> ProfileScreen(prefs, repo)
            }
        }
    }

    pending?.let { uri ->
        AlertDialog(
            onDismissRequest = { pending = null },
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            title = { Text("Новое видео") },
            text = {
                OutlinedTextField(
                    value = caption,
                    onValueChange = { caption = it.take(150) },
                    placeholder = { Text("Подпись (необязательно)") },
                    singleLine = false,
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    pending = null
                    tab = 0
                    scope.launch { repo.add(uri, caption, username) }
                }) { Text("Опубликовать") }
            },
            dismissButton = { TextButton(onClick = { pending = null }) { Text("Отмена") } },
        )
    }
}

@Composable
private fun navColors() = NavigationBarItemDefaults.colors(
    selectedIconColor = MaterialTheme.colorScheme.primary,
    selectedTextColor = MaterialTheme.colorScheme.primary,
    unselectedIconColor = Color(0xFF8A8A8E),
    unselectedTextColor = Color(0xFF8A8A8E),
    indicatorColor = Color.Transparent,
)

@Composable
private fun ProfileScreen(prefs: Prefs, repo: VideoRepo) {
    val scope = rememberCoroutineScope()
    val accent by prefs.accent.collectAsState(initial = AccentPalette[0])
    val streak by prefs.streak.collectAsState(initial = Streak(0, ""))
    val storedName by prefs.username.collectAsState(initial = "astra")
    val videos by repo.videos.collectAsState()
    var name by remember(storedName) { mutableStateOf(storedName) }

    Column(Modifier.fillMaxSize().padding(horizontal = 24.dp).statusBarsPadding()) {
        Spacer(Modifier.height(24.dp))

        OutlinedTextField(
            value = name,
            onValueChange = {
                name = it.take(24)
                scope.launch { prefs.setUsername(name) }
            },
            label = { Text("Имя") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )

        Spacer(Modifier.height(28.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "${streak.days}",
                style = MaterialTheme.typography.titleLarge.copy(color = MaterialTheme.colorScheme.primary),
            )
            Spacer(Modifier.width(10.dp))
            Text(
                if (streak.days == 0) "Начни серию — посмотри видео" else "дн. подряд",
                style = MaterialTheme.typography.bodyMedium,
            )
        }
        Spacer(Modifier.height(6.dp))
        Text(
            "Видео в Astra: ${videos.size}",
            color = Color(0xFF8A8A8E),
            style = MaterialTheme.typography.bodyMedium,
        )

        Spacer(Modifier.height(36.dp))
        Text("Цвет акцента", style = MaterialTheme.typography.labelMedium, color = Color(0xFF8A8A8E))
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            AccentPalette.forEach { c ->
                Box(
                    Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color(c))
                        .clickable { scope.launch { prefs.setAccent(c) } },
                    contentAlignment = Alignment.Center,
                ) {
                    if (c == accent) {
                        Icon(Icons.Filled.Check, null, tint = Color.Black, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}
