package app.astra

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

data class Video(
    val id: String,
    val path: String,
    val caption: String,
    val author: String,
    val createdAt: Long,
    val liked: Boolean,
)

/** Локальное хранилище: видео копируются в память приложения, список лежит в videos.json. */
class VideoRepo(private val context: Context) {
    private val dir = File(context.filesDir, "videos").apply { mkdirs() }
    private val index = File(context.filesDir, "videos.json")

    private val _videos = MutableStateFlow(read())
    val videos: StateFlow<List<Video>> = _videos

    private fun read(): List<Video> = runCatching {
        val arr = JSONArray(index.readText())
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Video(
                id = o.getString("id"),
                path = o.getString("path"),
                caption = o.optString("caption"),
                author = o.optString("author", "astra"),
                createdAt = o.optLong("createdAt"),
                liked = o.optBoolean("liked"),
            )
        }.filter { File(it.path).exists() }
    }.getOrDefault(emptyList())

    @Synchronized
    private fun save(list: List<Video>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id)
                    .put("path", it.path)
                    .put("caption", it.caption)
                    .put("author", it.author)
                    .put("createdAt", it.createdAt)
                    .put("liked", it.liked)
            )
        }
        index.writeText(arr.toString())
        _videos.value = list
    }

    suspend fun add(uri: Uri, caption: String, author: String): Boolean = withContext(Dispatchers.IO) {
        val id = UUID.randomUUID().toString()
        val out = File(dir, "$id.mp4")
        val copied = runCatching {
            context.contentResolver.openInputStream(uri)?.use { input ->
                out.outputStream().use { input.copyTo(it) }
                true
            } ?: false
        }.getOrDefault(false)
        if (!copied) {
            out.delete()
            return@withContext false
        }
        save(listOf(Video(id, out.absolutePath, caption.trim(), author, System.currentTimeMillis(), false)) + _videos.value)
        true
    }

    suspend fun toggleLike(id: String) = withContext(Dispatchers.IO) {
        save(_videos.value.map { if (it.id == id) it.copy(liked = !it.liked) else it })
    }

    suspend fun delete(id: String) = withContext(Dispatchers.IO) {
        _videos.value.firstOrNull { it.id == id }?.let { File(it.path).delete() }
        save(_videos.value.filterNot { it.id == id })
    }
}
