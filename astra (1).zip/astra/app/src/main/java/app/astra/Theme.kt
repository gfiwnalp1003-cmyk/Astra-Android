package app.astra

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val LocalAccent = staticCompositionLocalOf { Color(AccentPalette[0]) }

@Composable
fun AstraTheme(accent: Int, content: @Composable () -> Unit) {
    val a = Color(accent)
    val scheme = darkColorScheme(
        primary = a,
        onPrimary = if (a.luminanceApprox() > 0.6f) Color.Black else Color.White,
        background = Color.Black,
        surface = Color(0xFF0B0B0C),
        onBackground = Color.White,
        onSurface = Color.White,
        surfaceVariant = Color(0xFF161618),
        outline = Color(0xFF2A2A2D),
    )
    val type = Typography(
        titleLarge = TextStyle(fontSize = 22.sp, fontWeight = FontWeight.SemiBold),
        bodyMedium = TextStyle(fontSize = 14.sp),
        labelMedium = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Medium),
    )
    CompositionLocalProvider(LocalAccent provides a) {
        MaterialTheme(colorScheme = scheme, typography = type, content = content)
    }
}

private fun Color.luminanceApprox() = 0.2126f * red + 0.7152f * green + 0.0722f * blue
